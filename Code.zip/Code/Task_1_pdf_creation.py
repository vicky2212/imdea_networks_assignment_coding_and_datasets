import datetime
import pandas as pd

start_date = "2013-11-01"
end_date = "2013-12-31"


start = datetime.datetime.strptime(start_date, "%Y-%m-%d")
end = datetime.datetime.strptime(end_date, "%Y-%m-%d")

for date in pd.date_range(start, end):
    
    file_path_kag = f"/kaggle/input/harvard-dataset/sms-call-internet-mi-{date.strftime('%Y-%m-%d')}.txt"
    file_path = f"/kaggle/working/{date.strftime('%Y-%m-%d')}.csv"
    file_name1= f"{date.strftime('%Y-%m-%d')}.csv"
    file_name= f"df_internet_final-{date.strftime('%Y-%m-%d')}.csv"
    # Read TXT file into a pandas DataFrame
    df = pd.read_csv(file_path_kag, delimiter='\t')  # Adjust the delimiter if necessary
    # Save DataFrame as CSV
    df.to_csv(file_name1, index=False)
    #Name the columns
    column_names=["country_id","datetime",'countrycode','smsin','smsout','callin','callout','internet']
    df = pd.read_csv(file_path, names=column_names)
    #create a new dataset by removeing columns
    df_new = df.drop(columns=["smsin", "smsout","callin","callout"])
    #assign 0 to null values
    df_internet = df_new.fillna(0)
    #remove the 1st row ehich contains the "unnamed:7"
    df_internet_N=df_internet.drop(labels=0, axis=0)
    #convert the column data type from object to float
    df_internet_N['internet'] = df_internet_N['internet'].astype(float)
    #remove the rown which has values below than 0.1
    df_internet_final = df_internet_N.loc[(df_internet_N["internet"] > 0.1)]
    #convert timestamp to date time
    df_internet_final["datetime"] = pd.to_datetime(df_internet_final["datetime"],utc=True, unit='ms')
    # extract only the data which contain squre id 1
	df_internet_finalD = df_internet_final.loc[(df_internet_final["country_id"] == 1)]
	df_internet_finalD.to_csv(file_name, index=False)
    print(file_name)
    
# importing libraries
import pandas as pd
import glob
import os
  
# merging the files
joined_files = os.path.join("/kaggle/input/square-id-01", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df1 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
print(df1)

#save the combined file to csv
df1.to_csv('combine-dataset-for-sq-id-1.csv', index=False)

# Plot the pdf for the square id 1
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm


# Calculate PDF using a kernel density estimation (KDE) or a distribution function (e.g., Gaussian)
kde = norm(df1['internet'].mean(), df1['internet'].std())  # Using Gaussian distribution as an example

# Generate x-axis values for plotting
x = np.linspace(df1['internet'].min(), df1['internet'].max(), 100)

# Plotting the PDF graph
plt.plot(x, kde.pdf(x))

# Add labels and a legend
plt.xlabel('Internet')
plt.ylabel('Probability Density')
plt.legend()

# Display the plot
plt.show()