import datetime
import pandas as pd

start_date = "2013-11-01"
end_date = "2013-12-31"


start = datetime.datetime.strptime(start_date, "%Y-%m-%d")
end = datetime.datetime.strptime(end_date, "%Y-%m-%d")

for date in pd.date_range(start, end):
    
    file_path_kag = f"/kaggle/input/harvard-dataset/sms-call-internet-mi-{date.strftime('%Y-%m-%d')}.txt"
    file_path = f"/kaggle/working/{date.strftime('%Y-%m-%d')}.csv"
    file_name1= f"{date.strftime('%Y-%m-%d')}.csv"
    file_name= f"df_internet_final-{date.strftime('%Y-%m-%d')}.csv"
    # Read TXT file into a pandas DataFrame
    df = pd.read_csv(file_path_kag, delimiter='\t')  # Adjust the delimiter if necessary
    # Save DataFrame as CSV
    df.to_csv(file_name1, index=False)
    #Name the columns
    column_names=["country_id","datetime",'countrycode','smsin','smsout','callin','callout','internet']
    df = pd.read_csv(file_path, names=column_names)
    #create a new dataset by removeing columns
    df_new = df.drop(columns=["smsin", "smsout","callin","callout"])
    #assign 0 to null values
    df_internet = df_new.fillna(0)
    #remove the 1st row ehich contains the "unnamed:7"
    df_internet_N=df_internet.drop(labels=0, axis=0)
    #convert the column data type from object to float
    df_internet_N['internet'] = df_internet_N['internet'].astype(float)
    #remove the rown which has values below than 0.1
    df_internet_final = df_internet_N.loc[(df_internet_N["internet"] > 0.1)]
    #convert timestamp to date time
    df_internet_final["datetime"] = pd.to_datetime(df_internet_final["datetime"],utc=True, unit='ms')
    df_internet_final.to_csv(file_name, index=False)
    print(file_name)