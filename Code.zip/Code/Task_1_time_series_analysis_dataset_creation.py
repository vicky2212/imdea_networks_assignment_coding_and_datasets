#create two weeks data set for square id 4159
import datetime
import pandas as pd

start_date = "2013-11-01"
end_date = "2013-12-31"


start = datetime.datetime.strptime(start_date, "%Y-%m-%d")
end = datetime.datetime.strptime(end_date, "%Y-%m-%d")

for date in pd.date_range(start, end):
    file_name1= f"/kaggle/input/italy-cdr-two-month/df_internet_final-{date.strftime('%Y-%m-%d')}.csv"
    file_name2= f"df_internet_final-{date.strftime('%Y-%m-%d')}_{4159}.csv"
    # Read TXT file into a pandas DataFrame
    df = pd.read_csv(file_name1)  # Adjust the delimiter if necessary
    df_internet_finalD = df.loc[(df["country_id"] == 4159)]
    df_internet_finalD.to_csv(file_name2, index=False)
    

#create two weeks data set for square id 4556

for date in pd.date_range(start, end):
    file_name1= f"/kaggle/input/italy-cdr-two-month/df_internet_final-{date.strftime('%Y-%m-%d')}.csv"
    file_name2= f"df_internet_final-{date.strftime('%Y-%m-%d')}_{4556}.csv"
    # Read TXT file into a pandas DataFrame
    df = pd.read_csv(file_name1)  # Adjust the delimiter if necessary
    df_internet_finalD = df.loc[(df["country_id"] == 4556)]
    df_internet_finalD.to_csv(file_name2, index=False)
    
#create two weeks data set for square id for highest network traffic

#First we should find the max traffic square id
import pandas as pd
import glob
import os
  
# merging the files
joined_files = os.path.join("/kaggle/input/italy-cdr-two-month", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df1 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#create the dataset based on group by square id and with total network traffic of each square id
grouped = df1.groupby('country_id')['internet'].sum()
​
# Reset the index and add a column name
grouped_with_column_name = grouped.reset_index(name='total_internet')
​
# Print the result
print(grouped_with_column_name)
row_index = grouped_with_column_name.loc[grouped_with_column_name['total_internet'] == grouped_with_column_name['total_internet'].max()].index[0]

#Then create the dataset by comparing the country id with max traffic square id

for date in pd.date_range(start, end):
    file_name1= f"/kaggle/input/italy-cdr-two-month/df_internet_final-{date.strftime('%Y-%m-%d')}.csv"
    file_name2= f"df_internet_final-{date.strftime('%Y-%m-%d')}_{row_index}.csv"
    # Read TXT file into a pandas DataFrame
    df = pd.read_csv(file_name1)  # Adjust the delimiter if necessary
    df_internet_finalD = df.loc[(df["country_id"] == row_index)]
    df_internet_finalD.to_csv(file_name2, index=False)
 