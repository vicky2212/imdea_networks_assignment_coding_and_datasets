# importing libraries
import pandas as pd
import glob
import os
  
# merging the files for 4159
joined_files = os.path.join("/kaggle/input/training-4159", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df_train_4159 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#print(df_train_4159)
df_train_4159.to_csv('Training-dataset-4159.csv', index=False)

joined_files = os.path.join("/kaggle/input/testing-4159", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df_test_4159 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#print(df_test_4159)
df_test_4159.to_csv('Testing-dataset-4159.csv', index=False)

# merging the files for 4556
joined_files = os.path.join("/kaggle/input/training-4556", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df_train_4556 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#print(df_train_4556)
df_train_4556.to_csv('Training-dataset-4556.csv', index=False)

joined_files = os.path.join("/kaggle/input/testing-4556", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df_test_4556 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#print(df_test_4556)
df_test_4556.to_csv('Testing-dataset-4556.csv', index=False)

# merging the files for 5160
joined_files = os.path.join("/kaggle/input/training-5160", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df_train_5160 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#print(df_train_5160)
df_train_5160.to_csv('Training-dataset-5160.csv', index=False)

joined_files = os.path.join("/kaggle/input/testing-5160", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df_test_5160 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
#print(df_test_5160)
df_test_5160.to_csv('Testing-dataset-5160.csv', index=False)

files = ['/kaggle/working/Training-dataset-5160.csv', '/kaggle/working/Testing-dataset-5160.csv']
df = pd.DataFrame()
for file in files:
    data = pd.read_csv(file)
    df = pd.concat([df, data], axis=0)
df.to_csv('merged_files_5160.csv', index=False)
 
 
import tensorflow as tf 
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.model_selection import train_test_split
from keras.preprocessing.sequence import TimeseriesGenerator
from sklearn.preprocessing import MinMaxScaler,StandardScaler

mpl.rcParams['figure.figsize'] = (10, 8)
mpl.rcParams['axes.grid'] = False

df= pd.read_csv('/kaggle/working/merged_files_5160.csv')
print(df)
df.set_index('datetime')[['internet']].plot(subplots=True)

df_input=df[['internet']]

#Scaling
scaler = MinMaxScaler()
data_scaled=scaler.fit_transform(df_input)

data_scaled

features=data_scaled
target = data_scaled[:,0]

TimeseriesGenerator(features,target,length=2,sampling_rate=1,batch_size=1)[0]

#Train test split
xtrain,xtest,ytrain,ytest=train_test_split(features,target,test_size=0.20,random_state=123,shuffle=False)
xtrain.shape
xtest.shape
ytrain.shape
win_length=9541 # numof rows in xtest-1
batch_size=32
num_features=1
train_generator = TimeseriesGenerator(xtrain, ytrain, length=win_length, sampling_rate=1, batch_size=batch_size)
test_generator = TimeseriesGenerator(xtest, ytest, length=win_length, sampling_rate=1, batch_size=batch_size)

train_generator[0]

#Model - LSTM neural network

model = tf.keras.Sequential()

model.add(tf.keras.layers.LSTM(128,input_shape=(win_length,num_features),return_sequences=True))
model.add(tf.keras.layers.LeakyReLU(alpha=0.5))

model.add(tf.keras.layers.LSTM(128,return_sequences=True))
model.add(tf.keras.layers.LeakyReLU(alpha = 0.5))
model.add(tf.keras.layers.Dropout(0.3))

model.add(tf.keras.layers.LSTM(64,return_sequences=False))
model.add(tf.keras.layers.Dropout(0.3))

model.add(tf.keras.layers.Dense(1))

model.summary()

early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss',patience=2,mode='min')

model.compile(
    loss=tf.losses.MeanSquaredError(),
    optimizer=tf.optimizers.Adam(),
    metrics=[tf.metrics.MeanAbsoluteError()]
)

history = model.fit_generator(
    train_generator,
    epochs=50,
    validation_data=test_generator,
    shuffle=False,
    callbacks = [early_stopping]
)

model.evaluate_generator(test_generator,verbose=0)
predictions = model.predict_generator(test_generator)
predictions.shape
predictions
ytest
xtest
xtest.shape
xtest[:,1:][win_length:]
df_pred=pd.concat([pd.DataFrame(predictions), pd.DataFrame(xtest[:,1:][win_length:])],axis=1)
df_pred
rev_trans=scaler.inverse_transform(df_pred)
rev_trans
df_final=df_input[predictions.shape[0]*-1:]
df_final.count()
df_final['internet_Pred']=rev_trans[:,0]
df_final[['internet','internet_Pred']].plot()


from sklearn.metrics import mean_squared_error


import numpy as np



# Calculate absolute percentage error (APE)
ape = np.abs((df_final['internet'] - df_final['internet_Pred']) / df_final['internet'])

# Calculate mean absolute percentage error (MAPE)
mape = np.mean(ape)

print("Mean Absolute Percentage Error:", mape)