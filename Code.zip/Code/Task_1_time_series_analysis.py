#Combine the csv files together for each square id and group them based on the datetime
# First do this step for square id 4159
# importing Libraries

import pandas as pd
import glob
import os
  
# importing matplotlib module
import matplotlib.pyplot as plt
plt.style.use('default')
  
# %matplotlib inline: only draw static
# images in the notebook
%matplotlib inline

# importing Dataset of square id 4159
# merging the files
joined_files = os.path.join("/kaggle/input/square-id-4159-date-dataset", "df_internet_final-*.csv")
  
#joined_files["datetime"] = pd.to_datetime(joined_files["datetime"])
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df1 = pd.concat(map(pd.read_csv, joined_list),  ignore_index=True)
df1.sort_values(by = 'datetime', ascending = True, inplace = True)
print(df1)

groupeddf1 = df1.groupby('datetime')['internet'].sum()
groupeddf1 = groupeddf1.reset_index(name='internet_traffic')
groupeddf1=groupeddf1.set_index('datetime')

# Secondly do this step for square id 4556

joined_files = os.path.join("/kaggle/input/square-id-4556-date-dataset", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df2 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
df2.sort_values(by = 'datetime', ascending = True, inplace = True)
print(df2)

groupeddf2 = df2.groupby('datetime')['internet'].sum()
groupeddf2 = groupeddf2.reset_index(name='internet_traffic')
groupeddf2=groupeddf2.set_index('datetime')

# Then do this step for square id 5160
joined_files = os.path.join("/kaggle/input/square-id-5160-date-dataset", "df_internet_final-*.csv")
  
# A list of all joined files is returned
joined_list = glob.glob(joined_files)
  
# Finally, the files are joined
df3 = pd.concat(map(pd.read_csv, joined_list), ignore_index=True)
df3.sort_values(by = 'datetime', ascending = True, inplace = True)
print(df3)
groupeddf3 = df3.groupby('datetime')['internet'].sum()
groupeddf3 = groupeddf3.reset_index(name='internet_traffic')
groupeddf3=groupeddf3.set_index('datetime')

#Visualizing The time series of internet activity of square id 4159,4556 and 5160
  
# to set the plot size
plt.figure(figsize=(16, 8), dpi=150)

  
# using plot method to plot open prices.
# in plot method we set the label and color of the curve.
groupeddf1['internet_traffic'].plot(label='square id 4159', color='red')
groupeddf2['internet_traffic'].plot(label='square id 4556', color='blue')
groupeddf3['internet_traffic'].plot(label='square id of highest traffic are', color='orange')
  

# adding title to the plot
plt.title('The time series of internet activity of square id of 4159,4556 and highest traffic area')
  
# adding Label to the x-axis
plt.xlabel('datetime')
plt.xlabel('Internet traffic')
plt.xticks(rotation='vertical')
# adding legend to the curve
plt.legend()
